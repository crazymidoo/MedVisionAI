# Fracture  > 2025-06-29 5:28pm
https://universe.roboflow.com/braintumorcaption/fracture-9v4kc

Provided by a Roboflow user
License: CC BY 4.0

