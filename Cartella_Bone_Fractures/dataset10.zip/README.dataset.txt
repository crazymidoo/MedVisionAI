# Leg fracture > 2025-03-10 1:24am
https://universe.roboflow.com/leg-fracture/leg-fracture

Provided by a Roboflow user
License: CC BY 4.0

