# FracAtlas > 2025-03-03 2:49pm
https://universe.roboflow.com/bone-fracture-detection-aibwo/fracatlas-p7vbh

Provided by a Roboflow user
License: CC BY 4.0

